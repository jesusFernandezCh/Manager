@extends('layouts.app')
@section('title')
<div class="nav-title text-white col-12"> 
	<i class="icon-person"></i>
	<a href="{{ route('operations.index') }}">{{__('Operation')}}</a> > {{$operation->account->name}} > {{$operation->code}}
</div>
<div class="col-12">
	<div class="text-white">Status: {{$operation->operationStatus->name}}</div>
</div>

@endsection
{{-- @section('top-menu') --}}
    {{-- @include('pages.operation.top-menu') --}}
{{-- @endsection --}}
@section('maincontent')
<div class="page height-full">
	<div class="form-group" style="margin-top: 76px">
		@include('pages.operation.top-menu')
	</div>
	 <div class="container-fluid animatedParent animateOnce my-3">
        <div class="animated fadeInUpShort">
        	<div class="col-md-12">
	            <div class="card" style="margin-top:0px">
	                <div class="form-group">
	                    <div class="card-header white">
	                        <h6><i class=""></i> {{__('ORDER TERMS')}} </h6>
	                    </div>
	                </div>
	                <div class="card-body">
						{!! Form::model($operation,['route'=>["operations.update",$operation->id],'method'=>'PUT','class'=>'formlDinamic form','id'=>'DataUpdate']) !!}
						<div class="form-row">
							<div class="col-md-3">
								<div class="form-group" id="proforma_group">
									{!! Form::label('code', 'Order Name *', ['class'=>'col-form-label s-12', 'onclick'=>'inputClear(this.id)']) !!}
									{!! Form::text('code', $operation->code, ['class'=>'form-control r-0 light s-12', 'id'=>'code']) !!}
									<span class="code_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="date_group">
									{!! Form::label('date', 'Order date *', ['class'=>'col-form-label s-12', 'onclick'=>'inputClear(this.id)']) !!}
									{!! Form::text('date', $operation->created_at->format('d-m-Y'), ['class'=>'form-control r-0 light s-12', 'id'=>'date']) !!}
									<span class="date_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="operations_status_id_group">
									<i class=""></i>
									{!! Form::label('operations_status_id', 'Status *', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('operations_status_id', $status, null, ['class'=>'form-control r-0 light s-12', 'id'=>'operations_status_id']) !!}
									<span class="operations_status_id_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="principal_id">
									<i class=""></i>
									{!! Form::label('principal_id', 'Principal *', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('principal_id', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'principal_id']) !!}
									<span class="principal_id_span"></span>
								</div>
							</div>
							<div class="col-6 alert-info text-center" style="border-radius: 50px"><b>PURCHASE</b></div>
							<div class="col-6 alert-info text-center" style="border-radius: 50px"><b>SALE</b></div>
							<div class="col-md-6">
								<div class="form-group" id="suplier_id_group">
									<i class=""></i>
									{!! Form::label('supplier_id', 'Supplier *', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('supplier_id', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'supplier_id']) !!}
									<span class="supplier_id_span"></span>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group" id="customer_id_group">
									<i class=""></i>
									{!! Form::label('customer_id', 'Constummer', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('customer_id', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'customer_id']) !!}
									<span class="customer_id_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="suplier_commercial_id_group">
									<i class=""></i>
									{!! Form::label('suplier_commercial_id', 'Supplier Commercial', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('supplier_commercil_id', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'supplier_commercial_id']) !!}
									<span class="supplier_commercial_id_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="proforma_group">
									{!! Form::label('proforma', 'proforma', ['class'=>'col-form-label s-12', 'onclick'=>'inputClear(this.id)']) !!}
									{!! Form::text('proforma', null, ['class'=>'form-control r-0 light s-12', 'id'=>'proforma']) !!}
									<span class="proforma_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="custom_commercial_id_group">
									<i class=""></i>
									{!! Form::label('custom_commercial_id', 'Custom Commercial', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('custom_commercil_id', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'custom_commercial_id']) !!}
									<span class="custom_commercial_id_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="custom_ref_group">
									{!! Form::label('custom_ref', 'Custom Ref', ['class'=>'col-form-label s-12', 'onclick'=>'inputClear(this.id)']) !!}
									{!! Form::text('custom_ref', null, ['class'=>'form-control r-0 light s-12', 'id'=>'custom_ref']) !!}
									<span class="custom_ref_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="purchase_by_group">
									<i class=""></i>
									{!! Form::label('purchase_by', 'Purchase By', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('purchase_by', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'_purchase_by']) !!}
									<span class="purchase_by_span"></span>
								</div>
							</div>
							<div class="col-md-3 text-center">
								<div class="form-group" id="po_signed_group">
									<i class=""></i>
									<br>
									{!! Form::label('po_signed', 'PO Signed', ['class'=>'col-form-label s-12']) !!}
									<input type="checkbox" name="po_signed" value="1" class="" />
									<span class="po_signed_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="sale_by_group">
									<i class=""></i>
									{!! Form::label('sale_by', 'Sale By', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('sale_by', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'_sale_by']) !!}
									<span class="sale_by_span"></span>
								</div>
							</div>
							<div class="col-md-3 text-center">
								<div class="form-group" id="so_signed_group">
									<i class=""></i>
									<br>
									{!! Form::label('so_signed', 'SO Signed', ['class'=>'col-form-label s-12']) !!}
									<input type="checkbox" name="_so_signed" value="1" class="" />
									<span class="so_signed_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="purchase_broker_id_group">
									<i class=""></i>
									{!! Form::label('purchase_broker_id', 'Purchase Broker *', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('purchase_broker_id', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'_purchase_broker_id']) !!}
									<span class="purchase_broker_id_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="pb_roker_com_mt_group">
									{!! Form::label('pb_roker_com_mt', 'PBrokerComMT', ['class'=>'col-form-label s-12', 'onclick'=>'inputClear(this.id)']) !!}
									{!! Form::text('pb_roker_com_mt', null, ['class'=>'form-control r-0 light s-12', 'id'=>'_pb_roker_com_mt']) !!}
									<span class="pb_roker_com_mt_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="sale_broker">
									<i class=""></i>
									{!! Form::label('sale_broker', 'Sale Broker', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('sale_broker', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'_sale_broker']) !!}
									<span class="purchase_by_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="s_broker_com_mt_group">
									{!! Form::label('s_broker_com_mt', 'SBrokerComMt', ['class'=>'col-form-label s-12', 'onclick'=>'inputClear(this.id)']) !!}
									{!! Form::text('s_broker_com_mt', null, ['class'=>'form-control r-0 light s-12', 'id'=>'_s_broker_com_mt']) !!}
									<span class="s_broker_com_mt_span"></span>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group" id="supplier_bank_id">
									<i class=""></i>
									{!! Form::label('supplier_bank_id', 'Supplier Bank', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('supplier_bank_id', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'_supplier_bank_id']) !!}
									<span class="supplier_bank_id_span"></span>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group" id="customer_bank_id">
									<i class=""></i>
									{!! Form::label('customer_bank_id', 'Customer Bank', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('customer_bank_id', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'_supplier_bank_id']) !!}
									<span class="customer_bank_id_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="p_modality_id">
									<i class=""></i>
									{!! Form::label('p_modality_id', 'PModality', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('p_modality_id', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'_p_modality_id']) !!}
									<span class="p_modality_id_span"></span>
								</div>
							</div>
							<div class="col-md-1">
								<div class="form-group" id="s_advanced_group">
									{!! Form::label('s_advanced', '% avc', ['class'=>'col-form-label s-12', 'onclick'=>'inputClear(this.id)']) !!}
									{!! Form::text('s_advanced', null, ['class'=>'form-control r-0 light s-12', 'id'=>'_s_advanced']) !!}
									<span class="s_advanced_span"></span>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group" id="p_days_group">
									{!! Form::label('p_days', 'P Days', ['class'=>'col-form-label s-12', 'onclick'=>'inputClear(this.id)']) !!}
									{!! Form::text('p_days', null, ['class'=>'form-control r-0 light s-12', 'id'=>'_p_advanced']) !!}
									<span class="p_days_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="payment_id">
									<i class=""></i>
									{!! Form::label('payment_id', 'Payment', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('payment_id', $accounts, null, ['class'=>'form-control r-0 light s-12', 'id'=>'_payment_id']) !!}
									<span class="payment_id_span"></span>
								</div>
							</div>
							<div class="col-md-1">
								<div class="form-group" id="s_advanced_group">
									{!! Form::label('s_advanced', '% avc', ['class'=>'col-form-label s-12', 'onclick'=>'inputClear(this.id)']) !!}
									{!! Form::text('s_advanced', null, ['class'=>'form-control r-0 light s-12', 'id'=>'_s_advanced']) !!}
									<span class="s_advanced_span"></span>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group" id="p_days_group">
									{!! Form::label('p_days', 'S Days', ['class'=>'col-form-label s-12', 'onclick'=>'inputClear(this.id)']) !!}
									{!! Form::text('p_days', null, ['class'=>'form-control r-0 light s-12', 'id'=>'_p_advanced']) !!}
									<span class="p_days_span"></span>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group" id="incoterm">
									<i class=""></i>
									{!! Form::label('incoterm', 'incoterm', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('incoterm', $incoterms, null, ['class'=>'form-control r-0 light s-12', 'id'=>'incoterm']) !!}
									<span class="incoterm_span"></span>
								</div>
							</div>
							<div class="col-md-1">
								<div class="form-group" id="p_curr">
									<i class=""></i>
									{!! Form::label('p_curr', 'p_curr', ['class'=>'col-form-label s-12']) !!}
									{!! Form::select('p_curr', $currencys, null, ['class'=>'form-control r-0 light s-12', 'id'=>'_p_curr']) !!}
									<span class="p_curr_span"></span>
								</div>
							</div>			
							<div class="col-12 alert-info text-center" style="border-radius: 50px"><b>LOGISTCS</b></div>

							{!! Form::hidden('route', route('operations.index'), ['id'=>'route']) !!}
						</div>
						<br>
						<div class="col-md-12 text-right">
							<a href="{{ route('operations.index') }}" class="btn btn-default" data-dismiss="modal">{{__('Back')}}</a>
							<button type="submit" class="btn btn-primary"><i class="icon-save mr-2"></i>{{_('Save data')}}</button>
						</div>
						{!! Form::close() !!}
					</div>
				</div>
        	</div>
		</div>
	</div>
</div>
@endsection
@section('js')
<script>
    $(document).ready(function() {
        $('#resumen').addClass('active');
    });
</script>
@endsection

