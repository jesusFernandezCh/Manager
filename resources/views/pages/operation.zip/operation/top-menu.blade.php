<header class="blue accent-3 relative">
    <div class="container-fluid text-white">
        <div class="row justify-content-between">
            <ul class="nav nav-material nav-material-white responsive-tab" id="v-pills-tab" role="tablist">
                @if (isset($operations) || isset($status))
                <li>
                    <a class="nav-link" href="{{ route('operations.index') }}" role="tab" id="operations">
                        <i class="icon icon-package"></i> {{__('Operations')}}
                    </a>
                </li>
                @endif
                @if (isset($operation->id))
                <li>
                    <a class="nav-link" id="resumen" href="#" role="tab"
                    aria-controls="v-pills-buyers">
                        <i class=""></i> {{__('Resumen')}}
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="#" role="tab" id="meta">
                        <i class="icon icon-documents3"></i> {{__('Documents')}}
                    </a>
                </li>
                <li>
                    <a class="nav-link" href="#" role="tab" id="meta">
                        <i class=""></i> {{__('Payments')}}
                    </a>
                </li>
                <li>
                    <a class="nav-link" id="metaType" href="#" role="tab" >
                        <i class=""></i> {{__('History')}}
                    </a>
                </li>
                <li>
                    <a class="nav-link" id="contacts" href="#" role="tab" >
                        <i class="icon icon-contacts"></i> {{__('Contacts')}}
                    </a>
                </li>
                @endif
                <li>
                    <a class="nav-link" href="{{ route('status.index') }}" role="tab" id="status">
                        <i class="icon icon-package"></i> {{__('Status')}}
                    </a>
                </li>
            </ul>
        </div>
    </div>
</header>