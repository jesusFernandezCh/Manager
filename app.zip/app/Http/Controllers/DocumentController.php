<?php

namespace App\Http\Controllers;

use App\Document;
use App\Document_type;
use App\Account;
use App\Operation;
use App\Http\Requests\Document\CreateRequest;
use App\Http\Requests\Document\updateRequest;
use Illuminate\Http\Request;
use Session;
use Redirect;

class DocumentController extends Controller
{
    private $document;
    private $account;
    private $documentType;
    private $operation;
    /**
     * { function_description }
     *
     * @param      \App\Document  $document  The document
     */
    public function __construct(Document $document)
    {
        $this->document = $document;
        $this->account = Account::get()->pluck('name', 'id');
        $this->documentType = Document_type::get()->pluck('name', 'id');
        $this->operation = Operation::get()->pluck('name', 'id');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $document = $this->document->all();
        $account = $this->account->all();
        $documentType = $this->documentType->all();
        $operation = $this->operation->all();
        
        return view('pages.account.document.index',compact('document','documentType','account', 'operation'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreateRequest $request)
    {
        $file = $request->file('file');
        $name = $file->getClientOriginalName();
        $public_path = public_path();
        $url = $public_path.'/storage/';

       \Storage::disk('local')->put($name,  \File::get($file));

        $data = new Document; 
        $data->name = $request->name;
        $data->account_id = $request->account_id;
        $data->operation_id = $request->operation_id;
        $data->file = $url.$name;
        $data->save();
        $data->documentTypes()->sync($request->documentType);
        return response()->json(['message'=>'Documento registrado correctamente']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Document $document)
    {
        return response()->json($document);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Document $document)
    {
       
        $account = $this->account->all();
        $documentType = $this->documentType->all();
        $operation = $this->operation->all();
        
        return view('pages.account.document.edit-2',compact('document','documentType','account', 'operation'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(updateRequest $request, $id)
    {
        $document = Document::find($id);

        $document->name = $request->name;
        $document->account_id = $request->account_id;
        $document->operation_id = $request->operation_id;
       

        
        if($request->file('file'))
        {   
           
            unlink($document->file);

            $file = $request->file('file');
            $name = $file->getClientOriginalName();
            $public_path = public_path();
            $url = $public_path.'/storage/';

            $document->file = $url.$name;

           \Storage::disk('local')->put($name,  \File::get($file));

        }


        $document->save();
        $document->documentTypes()->sync($request->documentType);
        Session::flash('message-success','El documento '. $request->name.' fue editado correctamente.');
        return Redirect::to('document');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Document $document)
    {
        $documentv->delete();
        return response()->json(['message'=>'Documento eliminado correctamente']);
    }

    public function download($id)
    {
        $document = Document::find($id);
        $file = $document->file;

        return response()->download($file);

    }
}
