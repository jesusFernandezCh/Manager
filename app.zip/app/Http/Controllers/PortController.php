<?php

namespace App\Http\Controllers;
use App\Port;
use Illuminate\Http\Request;
use Session;
use Redirect;

class PortController extends Controller
{
    private $port;

    public function __construct(Port $port)
    {
      $this->port = $port;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $ports = $this->port->all();
      return view('pages.port.index', compact('ports'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->port->create($request->all());
        Session::flash('message-success',' Port '. $request->name.' creado correctamente.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Port $port)
    {
        return view('pages.port.edit',compact('port'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $port = $this->port->find($id);
        $port->update($request->all());
        $port->save();
        Session::flash('message-success',' Port '. $request->name.' editado correctamente.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Port $port)
    {
      $port->delete();
      Session::flash('message-success',' Port '. $port->name.' eliminado correctamente.');
    }
}
