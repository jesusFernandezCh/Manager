<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bank_account_type extends Model
{
    protected $fillable = [
        'name'
    ];
}
