<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bussines_line extends Model
{
    //
}
