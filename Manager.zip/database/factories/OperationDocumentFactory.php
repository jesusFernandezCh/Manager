<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\OperationDocument;
use Faker\Generator as Faker;

$factory->define(OperationDocument::class, function (Faker $faker) {
    return [
        //
    ];
});
