<header class="blue accent-3 relative">
    <div class="container-fluid text-white">

        <div class="row justify-content-between">
            <ul class="nav nav-material nav-material-white responsive-tab" id="v-pills-tab" role="tablist">
                <li>
                    <a class="nav-link" href="#" role="tab" aria-controls="v-pills-all"><i class=""></i>Accounts</a>
                </li>
                <li>
                    <a class="nav-link active" id="v-pills-buyers-tab" data-toggle="pill" href="#" role="tab"
                    aria-controls="v-pills-buyers"><i class=""></i> Accounts Categories</a>
                </li>
                <li>
                    <a class="nav-link" href="#" role="tab" aria-controls="v-pills-sellers"><i class=""></i> Account meta</a>
                </li>
                <li>
                    <a class="nav-link" href="#" role="tab" aria-controls="v-pills-sellers"><i class=""></i> Account meta type</a>
                </li>
                <li>
                    <a class="nav-link" href="#" role="tab" aria-controls="v-pills-sellers"><i class=""></i>Country</a>
                </li>

            </ul>
        </div>
    </div>
</header>
