<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\order_pmt_term;
use Faker\Generator as Faker;

$factory->define(order_pmt_term::class, function (Faker $faker) {
    return [
        //
    ];
});
