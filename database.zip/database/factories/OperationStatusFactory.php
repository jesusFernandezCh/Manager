<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\OperationStatus;
use Faker\Generator as Faker;

$factory->define(OperationStatus::class, function (Faker $faker) {
    return [
        //
    ];
});
