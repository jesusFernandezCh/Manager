<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\bussines_line;
use Faker\Generator as Faker;

$factory->define(bussines_line::class, function (Faker $faker) {
    return [
        //
    ];
});
