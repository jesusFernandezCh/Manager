<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\operationShip;
use Faker\Generator as Faker;

$factory->define(operationShip::class, function (Faker $faker) {
    return [
        //
    ];
});
