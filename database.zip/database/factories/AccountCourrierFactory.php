<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\AccountCourrier;
use Faker\Generator as Faker;

$factory->define(AccountCourrier::class, function (Faker $faker) {
    return [
        //
    ];
});
