<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\DocsInstruction;
use Faker\Generator as Faker;

$factory->define(DocsInstruction::class, function (Faker $faker) {
    return [
        //
    ];
});
