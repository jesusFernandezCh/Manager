<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\cargo_unit;
use Faker\Generator as Faker;

$factory->define(cargo_unit::class, function (Faker $faker) {
    return [
        //
    ];
});
